Category: Reverse Engineering / Binary Exploitation
Difficulty: easyyyyyy



Description :
Oops ! i lost the flag — can you find it?


Flag Format: 

CGLITCHERS{}
